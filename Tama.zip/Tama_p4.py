from random import randrange


class Pet():
    boredom_decrement = 4
    hunger_decrement = 6
    boredom_threshold = 5
    hunger_threshold = 10
    sounds = ['Mrrp']

    def __init__(self, name="Kitty"):
        self.name = name
        self.hunger = randrange(self.hunger_threshold)
        self.boredom = randrange(self.boredom_threshold)
        self.sounds = self.sounds[
                      :]  # copy the class attribute, so that when we make changes to it, we won't affect the other Pets in the class

    def clock_tick(self):
        self.boredom += 1
        self.hunger += 1

    def mood(self):
        if self.hunger <= self.hunger_threshold and self.boredom <= self.boredom_threshold:
            return "happy"
        elif self.hunger > self.hunger_threshold:
            return "hungry"
        else:
            return "bored"

    def __str__(self):
        state = "     I'm " + self.name + ". "
        state += " I feel " + self.mood() + ". "
        # state += "Hunger {} Boredom {} Words {}".format(self.hunger, self.boredom, self.sounds)
        return state

    def hi(self):
        print (self.sounds[randrange(len(self.sounds))])
        self.reduce_boredom()

    def teach(self, word):
        self.sounds.append(word)
        self.reduce_boredom()

    def feed(self):
        self.reduce_hunger()

    def reduce_hunger(self):
        self.hunger = max(0, self.hunger - self.hunger_decrement)

    def reduce_boredom(self):
        self.boredom = max(0, self.boredom - self.boredom_decrement)

        '''Существует также множество интересных способов использования пользовательских классов, которые не включают 
        данные из Интернета. Давайте потянем все эти механики в несколько более интересном виде, чем мы получили с 
        классом Point. Помните Тамагочи, маленьких электронных животных? Со временем они будут голодать или скучать. 
        Вам пришлось убираться после них, иначе они заболели. И вы сделали все это с помощью нескольких кнопок на 
        устройстве.
Мы собираемся сделать упрощенную текстовую версию этого. В вашей задаче и в главе «Наследование» <chap_inheritance> 
мы продолжим это.
Сначала начнем с класса Pet. Каждый экземпляр класса будет одним электронным питомцем для пользователя, которому 
нужно позаботиться. Каждый экземпляр будет иметь текущее состояние, состоящее из трех переменных экземпляра:
голод, целое число
скука, целое число
звуки, список строк, каждое слово, которое любимцу научили говорить
В методе __init__ голод и скука инициализируются случайными значениями между 0 и порогом для голодания или скуки. 
Переменная экземпляра звуков инициализируется как копия переменной класса с тем же именем. Причина, по которой мы 
делаем копию списка, состоит в том, что мы будем выполнять деструктивные операции (добавление новых звуков в список). 
Если мы не сделали копию, то эти деструктивные операции повлияют на список, на который указывает переменная класса,
 и, таким образом, научить звук любому из домашних животных научить его всем экземплярам класса!
Существует метод clock_tick, который просто увеличивает переменные экземпляра скуки и голода, имитируя идею о том,
 что с течением времени домашнее животное становится скучным и голодным.
Метод __str__ создает строковое представление текущего состояния домашнего животного, в частности, является ли оно
 скучным или голодным или является ли оно счастливым. Скучно, если переменная экземпляра скуки больше порога, 
 который задается как переменная класса.
Чтобы облегчить скуку, владелец домашнего животного может либо научить питомец новому слову, используя метод 
обучения (), либо взаимодействовать с домашним животным, используя метод hi (). В ответ на учение (), домашнее 
животное добавляет новое слово в свой список слов. В ответ на метод hi () он печатает одно из слов, которое он 
знает, случайно выбирая один из его списка известных слов. И hi (), и learn () вызывают вызов метода reduce_boredom (). 
Он уменьшает состояние скуки на сумму, которую он читает из переменной класса hunger_decrement. Состояние скуки 
никогда не может опускаться ниже 0.
Чтобы облегчить голод, мы вызываем метод feed ().'''


p1 = Pet("Fido")
print (p1)
for i in range(10):
    p1.clock_tick()
    print (p1)
p1.feed()
p1.hi()
p1.teach("Boo")
for i in range(10):
    p1.hi()
print (p1)


import sys
sys.setExecutionLimit(60000)

def whichone(petlist, name):
    for pet in petlist:
        if pet.name == name:
            return pet
    return None # no pet matched

def play():
    animals = []

    option = ""
    base_prompt = """
        Quit
        Adopt <petname_with_no_spaces_please>
        Greet <petname>
        Teach <petname> <word>
        Feed <petname>

        Choice: """
    feedback = ""
    while True:
        action = raw_input(feedback + "\n" + base_prompt)
        feedback = ""
        words = action.split()
        if len(words) > 0:
            command = words[0]
        else:
            command = None
        if command == "Quit":
            print("Exiting...")
            return
        elif command == "Adopt" and len(words) > 1:
            if whichone(animals, words[1]):
                feedback += "You already have a pet with that name\n"
            else:
                animals.append(Pet(words[1]))
        elif command == "Greet" and len(words) > 1:
            pet = whichone(animals, words[1])
            if not pet:
                feedback += "I didn't recognize that pet name. Please try again.\n"
                print
            else:
                pet.hi()
        elif command == "Teach" and len(words) > 2:
            pet = whichone(animals, words[1])
            if not pet:
                feedback += "I didn't recognize that pet name. Please try again."
            else:
                pet.teach(words[2])
        elif command == "Feed" and len(words) > 1:
            pet = whichone(animals, words[1])
            if not pet:
                feedback += "I didn't recognize that pet name. Please try again."
            else:
                pet.feed()
        else:
            feedback+= "I didn't understand that. Please try again."

        for pet in animals:
            pet.clock_tick()
            feedback += "\n" + pet.__str__()



play()




