class Tamagochi(object):
    def __init__(self):
        self.age = 1
        self.food = 10
        self.health = 10
        self.dream = 0

    def report_food(self):
        if self.food < 2:
            self.health -= 2
            return "\ntamagochi ochen goloden"
        if self.food < 5:
            self.health -= 1
            return "\nTamagochi goloden"
        return ">" * self.food

    def report_dream(self):
        if self.dream > 8:
            self.health -= 2
            return "\ntamagochi ochen sleep"
        if self.dream > 5:
            self.health -= 1
            return "\nTamagochi sleep"
        return "*" * self.dream



    def report_all(self):
        report = 'Time'

        self.age += 1

        report += self.report_dream()
        report += self.report_food()
        report += 'age: ' + str(self.age)

        return report

    def action(self, do):
        w = ''
        w = do.split()

        if w == 'b':
            self.dream -= 10
            self.food -= 10
        elif w == 'f':
            self.dream += 10
            self.food += 10

def counter_all(num):
    return '*' * num

def main():
    t = Tamagochi()
    print('ny nachnem\n')
    act = input(str)
    t.action(act)
    print(t.report_all())
    print('*' * 5)

if __name__ == '__main__':
    main()