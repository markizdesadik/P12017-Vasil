import re
import os
import datetime

today = datetime.datetime.today()
folder = os.getcwd() + '/Отчеты/'
file_list = os.listdir(folder)
file_dogovor = 'Договор_поставки'
file_schet = 'Счет-фактура'


put_k_antiword = 'C://antiword/'
pokypka = 'Покупатель: '
data_dogovor = 'Договор поставки №'
text_full = []
client = ''
num = ''
dat = ''
file_tab = []
os.chdir(folder)
print(file_list)
for file_in_folder in file_list:
    schet = False
    dogovor = False
    if not file_in_folder.find(file_dogovor):
        dogovor = True
    elif not file_in_folder.find(file_schet):
        schet = True

    if dogovor or schet:

        replace_name_file = file_in_folder.replace(' ', "")

        os.rename(file_in_folder, replace_name_file)

        os.system(put_k_antiword + 'antiword.exe -m cp1251 ' + folder + replace_name_file + ' > ' + folder + 'new_file.txt')
        with open('new_file.txt', 'r') as file:
            for row in file:
                text_full.append(row)

        if dogovor:
            for stroka in text_full:
                if pokypka in stroka:
                    client = (stroka[len(pokypka):].replace(' ', '').replace('|', '').replace('\n', ''))
                if data_dogovor in stroka:
                    num = (stroka[len(data_dogovor):].replace(' ', '').replace('/', '_').replace('|', '').
                           replace('\n', '').replace('№', 'N'))
                fuu = re.search(r'(от.)+\d\d\d\d.г', stroka)
                if fuu:
                    dat = (stroka.replace(' ', '').replace('г.', '_').replace('|', '').replace('\n', ''))
                rename_file = 'договор {} {} от {} {}.doc'.format(client, num, dat, today.microsecond)
                os.rename(replace_name_file, rename_file)

        if schet:
            for stroka in text_full:
                if pokypka in stroka:
                    client = (stroka[len(pokypka):].replace(' ', '').replace('|', '').replace('\n', ''))
                if data_dogovor in stroka:
                    num = (stroka[len(data_dogovor):].replace(' ', '').replace('/', '_').replace('|', '').
                           replace('\n', '').replace('№', 'N'))
                fuu = re.search(r'\d\d\d\d.г', stroka)
                if fuu:
                    dat = (stroka.replace(' ', '').replace('г.', '_').replace('|', '').replace('\n', ''))

                # rename_file = 'счет-фактура {} {} от {}.doc'.format(client, num, today.microsecond)
                # os.rename(replace_name_file, rename_file)
                print('счет-фактура {} {} от {} {}.doc'.format(client, num, dat, today.microsecond))
                print(client)
                print(num)
                print(dat)