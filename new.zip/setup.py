from distutils.core import setup
import py2exe, sys, os

setup(
    console=['client_name.py'],
    options={
        'py2exe': {
            'packages': ['reportlab']
        }
    }
)
